<?php

namespace Doctrine\DBAL\Exception;

final class ConnectionLost extends ConnectionException
{
}

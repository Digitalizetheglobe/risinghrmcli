<?php

return [
    'item1' => 'Item 1',
    'submenu1' => [
        'item1' => 'Submenu 1: Item 1',
    ],
];

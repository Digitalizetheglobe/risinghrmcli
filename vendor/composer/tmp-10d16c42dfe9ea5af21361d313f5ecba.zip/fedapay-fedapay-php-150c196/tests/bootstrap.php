<?php
require_once __DIR__ . '/Fixtures/Foo.php';
require_once __DIR__ . '/Fixtures/FooCurrency.php';
require_once __DIR__ . '/Fixtures/FooPerson.php';
require_once __DIR__ . '/Fixtures/FooTest.php';

require_once __DIR__ . '/BaseTestCase.php';

<?php
namespace Tests\Fixtures;

class FooPerson extends \FedaPay\Resource
{
}

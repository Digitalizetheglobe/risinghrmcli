<?php
namespace Tests\Fixtures;

class FooTest extends \FedaPay\Resource
{
}

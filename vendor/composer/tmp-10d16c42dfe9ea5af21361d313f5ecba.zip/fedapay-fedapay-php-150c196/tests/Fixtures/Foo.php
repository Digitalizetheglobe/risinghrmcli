<?php
namespace Tests\Fixtures;

class Foo extends \FedaPay\Resource
{
}

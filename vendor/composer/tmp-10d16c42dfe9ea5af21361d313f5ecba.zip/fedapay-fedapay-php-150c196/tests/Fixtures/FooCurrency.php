<?php
namespace Tests\Fixtures;

class FooCurrency extends \FedaPay\Resource
{
}

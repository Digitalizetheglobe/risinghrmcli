<?php

namespace FedaPay;

/**
 * Class PhoneNumber
 *
 * @property int $id
 * @property string $number
 * @property string $country
 * @property string $created_at
 * @property string $updated_at
 *
 * @package FedaPay
 */
class PhoneNumber extends Resource
{

}

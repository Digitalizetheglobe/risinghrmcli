<?php

namespace FedaPay\Error;

/**
 * Class InvalidRequest
 *
 * @package FedaPay\Error
 */
class InvalidRequest extends Base
{
}

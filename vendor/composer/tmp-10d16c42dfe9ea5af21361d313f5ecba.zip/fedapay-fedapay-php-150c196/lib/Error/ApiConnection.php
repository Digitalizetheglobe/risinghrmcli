<?php

namespace FedaPay\Error;

/**
 * Class ApiConnection
 *
 * @package FedaPay\Error
 */
class ApiConnection extends Base
{
}

<?php


namespace WhichBrowser\Constants;

class DeviceSubType
{
    const FEATURE = 'feature';
    const SMART = 'smart';
    const DESKTOP = 'desktop';
    const CONSOLE = 'console';
    const PORTABLE = 'portable';
}

<?php

return [
    'sid'               => env('TWILIO_SID', ''),
    'token'             => env('TWILIO_TOKEN', ''),
    'messaging_service' => env('TWILIO_MESSAGING_SERVICE', ''),
];

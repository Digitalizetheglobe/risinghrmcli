<?php

namespace Ds;

require __DIR__ . '/../vendor/autoload.php';

error_reporting(E_ALL);
